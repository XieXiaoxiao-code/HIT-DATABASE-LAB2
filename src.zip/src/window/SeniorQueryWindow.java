package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class SeniorQueryWindow extends JFrame{

	   public SeniorQueryWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var Button1 = new JButton("������Դ");
		      southPanel.add(Button1);
		      var Button2 = new JButton("���ʵ���·��");
		      southPanel.add(Button2);
		      var Button3 = new JButton("���пⷿ��ѯ");
		      southPanel.add(Button3);
		      var Button4 = new JButton("�ⷿ����������");
		      southPanel.add(Button4);
		      		
		      Button1.addActionListener(event ->
		      {		          	  
		    	  var passwordinwindow = new PassWordInWindow();
		    	  passwordinwindow.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  passwordinwindow.setVisible(true);		    	  
		      }
		    		  );
		      Button2.addActionListener(event ->
		      {		          	  
		    	  var passwordoutwindow = new PassWordOutWindow();
		    	  passwordoutwindow.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  passwordoutwindow.setVisible(true);
		      }
		    		  );
		      Button3.addActionListener(event ->
		      {		          	  
		    	  var queryemptystorehouse = new QueryEmptyStorehouse();
		    	  queryemptystorehouse.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  queryemptystorehouse.setVisible(true);
		      }
		    		  );
		      Button4.addActionListener(event ->
		      {		          	  
		    	  var querynumofgoodskinds = new QueryNumOfGoodsKinds();
		    	  querynumofgoodskinds.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querynumofgoodskinds.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
