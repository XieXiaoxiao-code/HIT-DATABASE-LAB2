package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class ShowWindow extends JFrame{

	   public static String Q;				
	   public static final int TEXTAREA_ROWS = 20;
	   public static final int TEXTAREA_COLUMNS = 50;
	   public static File file = new File("E:\\java-2022-032\\workspace\\Lab1\\src\\supplier\\show_all.txt");
	   public Connection GetConnection(String username, String passwd) {
			String driver = "org.postgresql.Driver";
			String sourceURL = "jdbc:postgresql://192.168.85.129:26000/storagesystem";		
			Connection conn = null;
			try {
				Class.forName(driver);
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			try {
				conn = DriverManager.getConnection(sourceURL, username, passwd);
				System.out.println("Connection succeed!");
				} catch (Exception e) {
					e.printStackTrace();
					return null;
					}
			return conn;
	   }
		public void Query(Connection conn, String Q) {
			Statement stmt = null;
			ResultSet rs = null;
			try {
			stmt = conn.createStatement();
			//ִ����ͨSQL��䡣
			rs = stmt.executeQuery(Q);
			PrintWriter output = new PrintWriter(file);
			while (rs.next()) {
				String sid = rs.getString(1);
				output.println(sid);
			}
			output.close();				//��ѯ���д��.txt�ļ�
			rs.close();
			stmt.close();
			}catch (SQLException e) {
				if (stmt != null) {
				try {
					rs.close();
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// result.txt�ļ�һ��Ҫ����
				e.printStackTrace();
			}
		}
	 public ShowWindow() {

	      var northPanel = new JPanel();
	      var southPanel = new JPanel();
	      northPanel.setLayout(new GridLayout(5, 2));
	      var Button1 = new JButton("չʾ");
	      northPanel.add(Button1);
	      add(southPanel, BorderLayout.SOUTH);
	      add(northPanel, BorderLayout.NORTH);

	      var textArea = new JTextArea("Ŀ¼:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
	      
	      add(textArea, BorderLayout.CENTER);
	      		
	      Button1.addActionListener(event ->
	      {		          	  
	    	  Q = "select tablename from pg_tables where schemaname=\'public\';";
	    	  System.out.println(Q);
	          Connection conn = GetConnection("joe", "20010403Me");
	          Query(conn, Q);
	    	  try {
		 			Scanner input = new Scanner(file);
		 			while (input.hasNextLine()) {
		 				textArea.append(input.nextLine()+"\n");	//����ѯ��������Ŀ���
		 			}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	    	  
	      }
	    		  );
	      
	      pack();
  }
}
