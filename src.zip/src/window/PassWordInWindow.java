package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class PassWordInWindow extends JFrame{

	   public static final int TEXTAREA_ROWS = 30;
	   public static final int TEXTAREA_COLUMNS = 70;
	   public static String view;
	   
	 public PassWordInWindow() {
		 
		 var password = new JPasswordField();
		 
	     var northPanel = new JPanel();
	     northPanel.setLayout(new GridLayout(2, 2));
	     northPanel.add(new JLabel("����������:", SwingConstants.LEFT));
	     northPanel.add(password);
	     add(northPanel, BorderLayout.NORTH);
	     var textArea = new JTextArea("��ʾ:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
	     var Button = new JButton("��֤");
	     var southPanel = new JPanel();
	     southPanel.add(Button);
	     add(textArea, BorderLayout.CENTER);
	     add(southPanel, BorderLayout.SOUTH);
      
	     Button.addActionListener(event ->
	     {		    	  
	    	 view = "";
	    	 if (password.getText().toString().equals("4321")) {
	    		 view = "";
	    		 textArea.append("������ȷ!");
	    		 var tracesource = new TraceSource();
		    	 tracesource.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	 tracesource.setVisible(true);
	    	 }
	    	 
	    	 else if (password.getText().toString().equals("1234")) {
	    		 view = "_view";
	    		 textArea.append("������ȷ!");
	    		 var tracesource = new TraceSource();
		    	 tracesource.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	 tracesource.setVisible(true);
	    	 }
	    	 
	    	 else {
	    		 textArea.append("�������!");	    		 
	    	 }
	     }
	    	  );
	     pack();
  }
}
