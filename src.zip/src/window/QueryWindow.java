package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class QueryWindow extends JFrame{

	   public QueryWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var Button1 = new JButton("������ѯ");
		      southPanel.add(Button1);
		      var Button2 = new JButton("�߼���ѯ");
		      southPanel.add(Button2);
		      		
		      Button1.addActionListener(event ->
		      {		          	  
		    	  var juniorquery = new JuniorQueryWindow();
		    	  juniorquery.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  juniorquery.setVisible(true);
		      }
		    		  );
		      Button2.addActionListener(event ->
		      {		          	  
		    	  var seniorquery = new SeniorQueryWindow();
		    	  seniorquery.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  seniorquery.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
