package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class InitWindow extends JFrame{
	public static final int TEXTAREA_ROWS = 100;
	   public static final int TEXTAREA_COLUMNS = 100;
	   public static String Q;				
	   public Connection GetConnection(String username, String passwd) {
			String driver = "org.postgresql.Driver";
			String sourceURL = "jdbc:postgresql://192.168.85.129:26000/db_tpcc";		
			Connection conn = null;
			try {
				Class.forName(driver);
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			try {
				conn = DriverManager.getConnection(sourceURL, username, passwd);
				System.out.println("Connection succeed!");
				} catch (Exception e) {
					e.printStackTrace();
					return null;
					}
			return conn;
	   }
	   
	   public InitWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var insertButton = new JButton("插入");
		      northPanel.add(insertButton);
		      var deleteButton = new JButton("删除");
		      northPanel.add(deleteButton);
		      var queryButton = new JButton("查询");
		      southPanel.add(queryButton);
		      var showButton = new JButton("目录");
		      southPanel.add(showButton);
		      	
		      insertButton.addActionListener(event ->
		      {		          	  
		    	  InsertWindow insert = new InsertWindow();
		    	  insert.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insert.setVisible(true);
		      }
		    		  );	
		      
		      deleteButton.addActionListener(event ->
		      {		          	  
		    	  DeleteWindow delete = new DeleteWindow();
		    	  delete.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  delete.setVisible(true);
		      }
		    		  );
		      
		      queryButton.addActionListener(event ->
		      {		          	  
		    	  QueryWindow query = new QueryWindow();
		    	  query.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  query.setVisible(true);
		      }
		    		  );
		      
		      showButton.addActionListener(event ->
		      {		          	  
		    	  ShowWindow show = new ShowWindow();
		    	  show.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  show.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
