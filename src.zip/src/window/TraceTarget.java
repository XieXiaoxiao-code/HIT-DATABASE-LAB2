package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * A frame with sample text components.
 */
public class TraceTarget extends JFrame
{
   public static final int TEXTAREA_ROWS = 20;
   public static final int TEXTAREA_COLUMNS = 70;
   public JTextArea textArea2 = new JTextArea("����:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
   public static File file = new File("E:\\java-2022-032\\workspace\\Lab1\\src\\supplier\\tracetarget.txt");		//��������м���ɶ�
   public static boolean first = true;
   public Connection GetConnection(String username, String passwd) {
		String driver = "org.postgresql.Driver";
		String sourceURL = "jdbc:postgresql://192.168.85.129:26000/storagesystem";		//��������
		Connection conn = null;
		try {//�������ݿ�������
			Class.forName(driver);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		try {//�������ݿ����ӡ�
			conn = DriverManager.getConnection(sourceURL, username, passwd);
			System.out.println("Connection succeed!");
			textArea2.append("���ӳɹ�!\n");
			} catch (Exception e) {
				e.printStackTrace();
				return null;
				}
		return conn;
   }
	public void Query(Connection conn, String Q) {
		Statement stmt = null;
		ResultSet rs = null;
		try {
		stmt = conn.createStatement();
		//ִ����ͨSQL��䡣
		rs = stmt.executeQuery(Q);
		PrintWriter output = new PrintWriter(file);
		while (rs.next()) {
			String sid1 = rs.getString(1);
			String sid2 = rs.getString(2);
			String sid3 = rs.getString(3);
			String sid5 = rs.getString(5);
			String sid6 = rs.getString(6);
			String sid7 = rs.getString(7);
			output.println(sid6+"	"+sid3+"	"+sid2
					+"	"+sid1+"		"+sid5+"	"+sid7);
		}
		output.close();				//��ѯ���д��result.txt�ļ�
		rs.close();
		stmt.close();
		}catch (SQLException e) {
			if (stmt != null) {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			}
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// result.txt�ļ�һ��Ҫ����
			e.printStackTrace();
		}
	}
	public String getQ(String name, String Q) {
		if (!Q.equals("")&&first) {
			first = false;
			if (Q.contains("%")) {
				return " where "+name + " like " + "\'" + Q + "\'";
			}
			else {
				return " where "+name + " = " + "\'" + Q + "\'";
			}
		}
		else if (!Q.equals("")&&!first) {
			if (Q.contains("%")) {
				return " and " + name + " like " + "\'" + Q + "\'";
			}
			else {
				return " and " + name + " = " + "\'" + Q + "\'";
			}
		}
		else {
			return "";
		}
	}
   public TraceTarget()
   {
     
      var goods_id = new JTextField();
      var department_id = new JTextField();
      var storehouse_id = new JTextField();					
      var out_store_bill_id = new JTextField();
      var sequence = new JTextField();
      var num = new JTextField();	
      
      var northPanel = new JPanel();
      northPanel.setLayout(new GridLayout(4, 2));
      northPanel.add(new JLabel("���ʱ���", SwingConstants.LEFT));
      northPanel.add(goods_id);
      northPanel.add(new JLabel("���ò��ű��", SwingConstants.LEFT));
      northPanel.add(department_id);
      northPanel.add(new JLabel("�ⷿ���", SwingConstants.LEFT));
      northPanel.add(storehouse_id);
      northPanel.add(new JLabel("���ⵥ���", SwingConstants.LEFT));
      northPanel.add(out_store_bill_id);
      northPanel.add(new JLabel("���", SwingConstants.LEFT));
      northPanel.add(sequence);
      northPanel.add(new JLabel("����", SwingConstants.LEFT));
      northPanel.add(num);

      add(northPanel, BorderLayout.NORTH);

      var textArea = new JTextArea("��ѯ���:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
      
      add(textArea, BorderLayout.WEST);
      add(textArea2, BorderLayout.EAST);

      var southPanel = new JPanel();

      var insertButton = new JButton("��ѯ");
      northPanel.add(insertButton);
      
      StringBuilder quary=new StringBuilder();
      insertButton.addActionListener(event ->
      {  
    	  first = true;
    	  textArea.setText("��ѯ���:\n");
    	  String Q = "select * from out_store_bill a inner join out_store_bill_detail"+ PassWordOutWindow.view +" b\n"
    			  	+ "on a.out_store_bill_id = b.out_store_bill_id\n"
    			  	+ "inner join storehouse c\n"
    			  	+ "on a.storehouse_id = c.storehouse_id\n"
    			  	+ "inner join department d\n"
    			  	+ "on a.department_id = d.department_id"
    	  			+ getQ("goods_id", goods_id.getText().toString())
    	  			+ getQ("a.department_id", department_id.getText().toString())
    	  			+ getQ("a.storehouse_id", storehouse_id.getText().toString())
    	  			+ getQ("a.out_store_bill_id", out_store_bill_id.getText().toString())
    	  			+ getQ("sequence", sequence.getText().toString())
    	  			+ getQ("num", num.getText().toString());
    	  System.out.println(Q);
          Connection conn = GetConnection("joe", "20010403Me");
          Query(conn, Q);
          textArea.append("goods_id	department_id	storehouse_id	out_store_bill_id	sequence	num\n");
          try {
 			Scanner input = new Scanner(file);
 			while (input.hasNextLine()) {
 				textArea.append(input.nextLine()+"\n");	//����ѯ��������Ŀ���
 			}
 		} catch (FileNotFoundException e) {
 			// result.txt�ļ�Ҫ����
 			e.printStackTrace();
 		}
          Q="";
          quary.delete(0, quary.length());
      }
    		  );
      add(southPanel, BorderLayout.SOUTH);
      pack();
   }
}
