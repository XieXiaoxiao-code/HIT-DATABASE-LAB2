package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class InsertWindow extends JFrame{

	   public InsertWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var Button1 = new JButton("��Ӧ��");
		      southPanel.add(Button1);
		      var Button2 = new JButton("�ⷿ");
		      southPanel.add(Button2);
		      var Button3 = new JButton("����");
		      southPanel.add(Button3);
		      var Button4 = new JButton("����");
		      southPanel.add(Button4);
		      var Button5 = new JButton("��ⵥ");
		      southPanel.add(Button5);
		      var Button6 = new JButton("�������");
		      southPanel.add(Button6);
		      var Button7 = new JButton("���ⵥ");
		      southPanel.add(Button7);
		      var Button8 = new JButton("��ⵥ��ϸ");
		      southPanel.add(Button8);
		      var Button9 = new JButton("���ⵥ��ϸ");
		      southPanel.add(Button9);
		      		
		      Button1.addActionListener(event ->
		      {		          	  
		    	  var insertsupplier = new InsertSupplier();
		    	  insertsupplier.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertsupplier.setVisible(true);
		      }
		    		  );
		      Button2.addActionListener(event ->
		      {		          	  
		    	  var insertstorehouse = new InsertStorehouse();
		    	  insertstorehouse.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertstorehouse.setVisible(true);
		      }
		    		  );
		      Button3.addActionListener(event ->
		      {		          	  
		    	  var insertgoods = new InsertGoods();
		    	  insertgoods.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertgoods.setVisible(true);
		      }
		    		  );
		      Button4.addActionListener(event ->
		      {		          	  
		    	  var insertdepartment = new InsertDepartment();
		    	  insertdepartment.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertdepartment.setVisible(true);
		      }
		    		  );
		      Button5.addActionListener(event ->
		      {		          	  
		    	  var insertinstorebill = new InsertInStoreBill();
		    	  insertinstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertinstorebill.setVisible(true);
		      }
		    		  );
		      Button6.addActionListener(event ->
		      {		          	  
		    	  var inserttotalstorebill = new InsertTotalStoreBill();
		    	  inserttotalstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  inserttotalstorebill.setVisible(true);
		      }
		    		  );
		      Button7.addActionListener(event ->
		      {		          	  
		    	  var insertoutstorebill = new InsertOutStoreBill();
		    	  insertoutstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertoutstorebill.setVisible(true);
		      }
		    		  );
		      Button8.addActionListener(event ->
		      {		          	  
		    	  var insertinstorebilldetail = new InsertInStoreBillDetail();
		    	  insertinstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertinstorebilldetail.setVisible(true);
		      }
		    		  );
		      Button9.addActionListener(event ->
		      {		          	  
		    	  var insertoutstorebilldetail = new InsertOutStoreBillDetail();
		    	  insertoutstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  insertoutstorebilldetail.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
