package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * A frame with sample text components.
 */
public class QueryGoods extends JFrame
{
   public static final int TEXTAREA_ROWS = 20;
   public static final int TEXTAREA_COLUMNS = 70;
   public JTextArea textArea2 = new JTextArea("����:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
   public static File file = new File("E:\\java-2022-032\\workspace\\Lab1\\src\\supplier\\querygoods.txt");		//��������м���ɶ�
   public static boolean first = true;
   public Connection GetConnection(String username, String passwd) {
		String driver = "org.postgresql.Driver";
		String sourceURL = "jdbc:postgresql://192.168.85.129:26000/storagesystem";		//��������
		Connection conn = null;
		try {//�������ݿ�������
			Class.forName(driver);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		try {//�������ݿ����ӡ�
			conn = DriverManager.getConnection(sourceURL, username, passwd);
			System.out.println("Connection succeed!");
			textArea2.append("���ӳɹ�!\n");
			} catch (Exception e) {
				e.printStackTrace();
				return null;
				}
		return conn;
   }
	public void Query(Connection conn, String Q) {
		Statement stmt = null;
		ResultSet rs = null;
		try {
		stmt = conn.createStatement();
		//ִ����ͨSQL��䡣
		rs = stmt.executeQuery(Q);
		PrintWriter output = new PrintWriter(file);
		while (rs.next()) {
			String sid1 = rs.getString(1);
			output.println(sid1);
		}
		output.close();				//��ѯ���д��result.txt�ļ�
		rs.close();
		stmt.close();
		}catch (SQLException e) {
			if (stmt != null) {
			try {
				rs.close();
				stmt.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			}
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// result.txt�ļ�һ��Ҫ����
			e.printStackTrace();
		}
	}
	public String getQ(String name, String Q) {
		if (!Q.equals("")&&first) {
			first = false;
			if (Q.contains("%")) {
				return " where "+name + " like " + "\'" + Q + "\'";
			}
			else {
				return " where "+name + " = " + "\'" + Q + "\'";
			}
		}
		else if (!Q.equals("")&&!first) {
			if (Q.contains("%")) {
				return " and " + name + " like " + "\'" + Q + "\'";
			}
			else {
				return " and " + name + " = " + "\'" + Q + "\'";
			}
		}
		else {
			return "";
		}
	}
   public QueryGoods()
   {				
      var goods_id = new JTextField();

      var northPanel = new JPanel();
      northPanel.setLayout(new GridLayout(5, 2));
      northPanel.add(new JLabel("���ʱ���", SwingConstants.LEFT));
      northPanel.add(goods_id);

      add(northPanel, BorderLayout.NORTH);

      var textArea = new JTextArea("��ѯ���:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
      
      add(textArea, BorderLayout.WEST);
      add(textArea2, BorderLayout.EAST);

      var southPanel = new JPanel();

      var insertButton = new JButton("��ѯ");
      northPanel.add(insertButton);
      
      StringBuilder quary=new StringBuilder();
      insertButton.addActionListener(event ->
      {  
    	  first = true;
    	  textArea.setText("��ѯ���:\n");
    	  String Q = "select * from goods"
    			  + getQ("goods_id", goods_id.getText().toString());
    	  System.out.println(Q);
          Connection conn = GetConnection("joe", "20010403Me");
          Query(conn, Q);
          textArea.append("goods_id\n");
          try {
 			Scanner input = new Scanner(file);
 			while (input.hasNextLine()) {
 				textArea.append(input.nextLine()+"\n");	//����ѯ��������Ŀ���
 			}
 		} catch (FileNotFoundException e) {
 			// result.txt�ļ�Ҫ����
 			e.printStackTrace();
 		}
          Q="";
          quary.delete(0, quary.length());
      }
    		  );
      add(southPanel, BorderLayout.SOUTH);
      pack();
   }
}
