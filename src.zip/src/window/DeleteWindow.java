package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class DeleteWindow extends JFrame{

	   public DeleteWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var Button1 = new JButton("��Ӧ��");
		      southPanel.add(Button1);
		      var Button2 = new JButton("�ⷿ");
		      southPanel.add(Button2);
		      var Button3 = new JButton("����");
		      southPanel.add(Button3);
		      var Button4 = new JButton("����");
		      southPanel.add(Button4);
		      var Button5 = new JButton("��ⵥ");
		      southPanel.add(Button5);
		      var Button6 = new JButton("�������");
		      southPanel.add(Button6);
		      var Button7 = new JButton("���ⵥ");
		      southPanel.add(Button7);
		      var Button8 = new JButton("��ⵥ��ϸ");
		      southPanel.add(Button8);
		      var Button9 = new JButton("���ⵥ��ϸ");
		      southPanel.add(Button9);
		      		
		      Button1.addActionListener(event ->
		      {		          	  
		    	  var deletesupplier = new DeleteSupplier();
		    	  deletesupplier.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deletesupplier.setVisible(true);
		      }
		    		  );
		      Button2.addActionListener(event ->
		      {		          	  
		    	  var deletestorehouse = new DeleteStorehouse();
		    	  deletestorehouse.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deletestorehouse.setVisible(true);
		      }
		    		  );
		      Button3.addActionListener(event ->
		      {		          	  
		    	  var deletegoods = new DeleteGoods();
		    	  deletegoods.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deletegoods.setVisible(true);
		      }
		    		  );
		      Button4.addActionListener(event ->
		      {		          	  
		    	  var deletedepartment = new DeleteDepartment();
		    	  deletedepartment.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deletedepartment.setVisible(true);
		      }
		    		  );
		      Button5.addActionListener(event ->
		      {		          	  
		    	  var deleteinstorebill = new DeleteInStoreBill();
		    	  deleteinstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deleteinstorebill.setVisible(true);
		      }
		    		  );
		      Button6.addActionListener(event ->
		      {		          	  
		    	  var deletetotalstorebill = new DeleteTotalStoreBill();
		    	  deletetotalstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deletetotalstorebill.setVisible(true);
		      }
		    		  );
		      Button7.addActionListener(event ->
		      {		          	  
		    	  var deleteoutstorebill = new DeleteOutStoreBill();
		    	  deleteoutstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deleteoutstorebill.setVisible(true);
		      }
		    		  );
		      Button8.addActionListener(event ->
		      {		          	  
		    	  var deleteinstorebilldetail = new DeleteInStoreBillDetail();
		    	  deleteinstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deleteinstorebilldetail.setVisible(true);
		      }
		    		  );
		      Button9.addActionListener(event ->
		      {		          	  
		    	  var deleteoutstorebilldetail = new DeleteOutStoreBillDetail();
		    	  deleteoutstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  deleteoutstorebilldetail.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
