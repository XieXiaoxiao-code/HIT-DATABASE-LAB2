package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class DeleteTotalStoreBill extends JFrame{

	   public static String Q;				
	   public static final int TEXTAREA_ROWS = 30;
	   public static final int TEXTAREA_COLUMNS = 70;
	   public static File file = new File("E:\\java-2022-032\\workspace\\Lab1\\src\\supplier\\deletetotalstorebill.txt");
	   public JTextArea textArea2 = new JTextArea("����:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
	   boolean first = true;
	   public Connection GetConnection(String username, String passwd) {
			String driver = "org.postgresql.Driver";
			String sourceURL = "jdbc:postgresql://192.168.85.129:26000/storagesystem";		
			Connection conn = null;
			try {
				Class.forName(driver);
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			try {
				conn = DriverManager.getConnection(sourceURL, username, passwd);
				System.out.println("Connection succeed!");
				textArea2.append("���ӳɹ�!\n");
				} catch (Exception e) {
					e.printStackTrace();
					return null;
					}
			return conn;
	   }
		public void Delete(Connection conn, String Q) throws FileNotFoundException {
			Statement stmt = null;
			try {
			stmt = conn.createStatement();
			stmt.execute(Q);
			var output = new PrintWriter(file);
			stmt.close();
			}catch (SQLException e) {
				textArea2.append("����������ϵ!\n");
				if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				e.printStackTrace();
			}
		}
		
		public void Query(Connection conn, String Q) {
			Statement stmt = null;
			ResultSet rs = null;
			try {
			stmt = conn.createStatement();
			//ִ����ͨSQL��䡣
			rs = stmt.executeQuery(Q);
			PrintWriter output = new PrintWriter(file);
			while (rs.next()) {
				String sid1 = rs.getString(1);
				String sid2 = rs.getString(2);
				String sid3 = rs.getString(3);
				output.println(sid1+"	"+sid2+"	"+sid3);
			}
			output.close();				//��ѯ���д��.txt�ļ�
			rs.close();
			stmt.close();
			}catch (SQLException e) {
				if (stmt != null) {
				try {
					rs.close();
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// result.txt�ļ�һ��Ҫ����
				e.printStackTrace();
			}
		}
		
		public String getQ(String name, String Q) {
			if (!Q.equals("")&&first) {
				first = false;
				if (Q.contains("%")) {
					return " where "+name + " like " + "\'" + Q + "\'";
				}
				else {
					return " where "+name + " = " + "\'" + Q + "\'";
				}
			}
			else if (!Q.equals("")&&!first) {
				if (Q.contains("%")) {
					return " and " + name + " like " + "\'" + Q + "\'";
				}
				else {
					return " and " + name + " = " + "\'" + Q + "\'";
				}
			}
			else {
				return "";
			}
		}
		
	 public DeleteTotalStoreBill() {

	      var northPanel = new JPanel();
	      var storehouse_id = new JTextField();
	      var goods_id = new JTextField();
	      var num = new JTextField();
	      var southPanel = new JPanel();
	      northPanel.setLayout(new GridLayout(5, 2));
	      northPanel.add(new JLabel("�ⷿ��� ", SwingConstants.LEFT));
	      northPanel.add(storehouse_id);
	      northPanel.add(new JLabel("���ʱ�� ", SwingConstants.LEFT));
	      northPanel.add(goods_id);
	      northPanel.add(new JLabel("��� ", SwingConstants.LEFT));
	      northPanel.add(num);
	      var Button1 = new JButton("ɾ��");
	      northPanel.add(Button1);
	      var Button2 = new JButton("ʣ��");
	      northPanel.add(Button1);
	      southPanel.add(Button2);
	      add(southPanel, BorderLayout.SOUTH);
	      add(northPanel, BorderLayout.NORTH);

	      var textArea = new JTextArea("ʣ��Ԫ��:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);

	      add(textArea, BorderLayout.WEST);
	      add(textArea2, BorderLayout.EAST);
	      		
	      Button1.addActionListener(event ->
	      {	     	  
          	  Q = "delete from total_store_bill "
	    			  +getQ("storehouse_id", storehouse_id.getText().toString())
	    			  +getQ("goods_id", goods_id.getText().toString())
	    			  +getQ("num", num.getText().toString())+";";
	    	  System.out.println(Q);
	          Connection conn = GetConnection("joe", "20010403Me");
	    	  try {
				Delete(conn, Q);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	    	  
	      }
	    		  );
	      
	      Button2.addActionListener(event ->
	      {		
	    	  first = true;		      
	    	  textArea.setText("��ѯ���:\n");      
	    	  textArea.append("storehouse_id	goods_id	num\n");
	          Q="select * from total_store_bill;";
	          Connection conn = GetConnection("joe", "20010403Me");
	 		  Query(conn, Q);
	          try {
	 			Scanner input = new Scanner(file);
	 			while (input.hasNextLine()) {
	 				textArea.append(input.nextLine()+"\n");	//����ѯ��������Ŀ���
	 			}
		        input.close();
	 		} catch (FileNotFoundException e) {
	 			// result.txt�ļ�Ҫ����
	 			e.printStackTrace();
	 		}  
	      }
	    		  );
	      pack();
  }
}
