package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class JuniorQueryWindow extends JFrame{

	   public JuniorQueryWindow() {

		      var northPanel = new JPanel();

		      var southPanel = new JPanel();

		      var Button1 = new JButton("��Ӧ��");
		      southPanel.add(Button1);
		      var Button2 = new JButton("�ⷿ");
		      southPanel.add(Button2);
		      var Button3 = new JButton("����");
		      southPanel.add(Button3);
		      var Button4 = new JButton("����");
		      southPanel.add(Button4);
		      var Button5 = new JButton("��ⵥ");
		      southPanel.add(Button5);
		      var Button6 = new JButton("�������");
		      southPanel.add(Button6);
		      var Button7 = new JButton("���ⵥ");
		      southPanel.add(Button7);
		      var Button8 = new JButton("��ⵥ��ϸ");
		      southPanel.add(Button8);
		      var Button9 = new JButton("���ⵥ��ϸ");
		      southPanel.add(Button9);
		      		
		      Button1.addActionListener(event ->
		      {		          	  
		    	  var querysupplier = new QuerySupplier();
		    	  querysupplier.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querysupplier.setVisible(true);
		      }
		    		  );
		      Button2.addActionListener(event ->
		      {		          	  
		    	  var querystorehouse = new QueryStorehouse();
		    	  querystorehouse.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querystorehouse.setVisible(true);
		      }
		    		  );
		      Button3.addActionListener(event ->
		      {		          	  
		    	  var querygoods = new QueryGoods();
		    	  querygoods.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querygoods.setVisible(true);
		      }
		    		  );
		      Button4.addActionListener(event ->
		      {		          	  
		    	  var querydepartment = new QueryDepartment();
		    	  querydepartment.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querydepartment.setVisible(true);
		      }
		    		  );
		      Button5.addActionListener(event ->
		      {		          	  
		    	  var queryinstorebill = new QueryInStoreBill();
		    	  queryinstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  queryinstorebill.setVisible(true);
		      }
		    		  );
		      Button6.addActionListener(event ->
		      {		          	  
		    	  var querytotalstorebill = new QueryTotalStoreBill();
		    	  querytotalstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  querytotalstorebill.setVisible(true);
		      }
		    		  );
		      Button7.addActionListener(event ->
		      {		          	  
		    	  var queryoutstorebill = new QueryOutStoreBill();
		    	  queryoutstorebill.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  queryoutstorebill.setVisible(true);
		      }
		    		  );
		      Button8.addActionListener(event ->
		      {		          	  
		    	  var queryinstorebilldetail = new QueryInStoreBillDetail();
		    	  queryinstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  queryinstorebilldetail.setVisible(true);
		      }
		    		  );
		      Button9.addActionListener(event ->
		      {		          	  
		    	  var queryoutstorebilldetail = new QueryOutStoreBillDetail();
		    	  queryoutstorebilldetail.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		    	  queryoutstorebilldetail.setVisible(true);
		      }
		    		  );
		      add(northPanel, BorderLayout.NORTH);
		      add(southPanel, BorderLayout.SOUTH);
		      pack();
	   }
}
