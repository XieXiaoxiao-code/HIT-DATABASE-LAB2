package window;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class DeleteInStoreBill extends JFrame{

	   public static String Q;				
	   public static final int TEXTAREA_ROWS = 30;
	   public static final int TEXTAREA_COLUMNS = 70;
	   public static File file = new File("E:\\java-2022-032\\workspace\\Lab1\\src\\supplier\\deleteinstorebill.txt");
	   public JTextArea textArea2 = new JTextArea("����:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);
	   public boolean first = true;
	   public Connection GetConnection(String username, String passwd) {
			String driver = "org.postgresql.Driver";
			String sourceURL = "jdbc:postgresql://192.168.85.129:26000/storagesystem";		
			Connection conn = null;
			try {
				Class.forName(driver);
				} catch (Exception e) {
					e.printStackTrace();
					return null;
				}
			try {
				conn = DriverManager.getConnection(sourceURL, username, passwd);
				System.out.println("Connection succeed!");
				textArea2.append("���ӳɹ�!\n");
				} catch (Exception e) {
					e.printStackTrace();
					return null;
					}
			return conn;
	   }
		public void Delete(Connection conn, String Q) throws FileNotFoundException {
			Statement stmt = null;
			try {
			stmt = conn.createStatement();
			stmt.execute(Q);
			var output = new PrintWriter(file);
			stmt.close();
			}catch (SQLException e) {
				if(e.getMessage().contains("constraint")) {
					textArea2.append("����������ϵ!\n");
				}
				if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				e.printStackTrace();
			}
		}
		public void Query(Connection conn, String Q) {
			Statement stmt = null;
			ResultSet rs = null;
			try {
			stmt = conn.createStatement();
			//ִ����ͨSQL��䡣
			rs = stmt.executeQuery(Q);
			PrintWriter output = new PrintWriter(file);
			while (rs.next()) {
				String sid1 = rs.getString(1);
				String sid2 = rs.getString(2);
				String sid3 = rs.getString(3);
				output.println(sid1+"	"+sid2+"	"+sid3);
			}
			output.close();				//��ѯ���д��.txt�ļ�
			rs.close();
			stmt.close();
			}catch (SQLException e) {
				if (stmt != null) {
				try {
					rs.close();
					stmt.close();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				}
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// result.txt�ļ�һ��Ҫ����
				e.printStackTrace();
			}
		}
		
		public String getQ(String name, String Q) {
			if (!Q.equals("")&&first) {
				first = false;
				if (Q.contains("%")) {
					return " where "+name + " like " + "\'" + Q + "\'";
				}
				else {
					return " where "+name + " = " + "\'" + Q + "\'";
				}
			}
			else if (!Q.equals("")&&!first) {
				if (Q.contains("%")) {
					return " and " + name + " like " + "\'" + Q + "\'";
				}
				else {
					return " and " + name + " = " + "\'" + Q + "\'";
				}
			}
			else {
				return "";
			}
		}
		
	 public DeleteInStoreBill() {

	      var northPanel = new JPanel();
	      var in_store_bill_id = new JTextField();
	      var storehouse_id = new JTextField();
	      var supplier_id = new JTextField();
	      var southPanel = new JPanel();
	      northPanel.setLayout(new GridLayout(5, 2));
	      northPanel.add(new JLabel("���ⵥ��� ", SwingConstants.LEFT));
	      northPanel.add(in_store_bill_id);
	      northPanel.add(new JLabel("�ⷿ��� ", SwingConstants.LEFT));
	      northPanel.add(storehouse_id);
	      northPanel.add(new JLabel("���ò��ű�� ", SwingConstants.LEFT));
	      northPanel.add(supplier_id);
	      var Button1 = new JButton("ɾ��");
	      northPanel.add(Button1);
	      var Button2 = new JButton("ʣ��");
	      northPanel.add(Button1);
	      southPanel.add(Button2);
	      add(southPanel, BorderLayout.SOUTH);
	      add(northPanel, BorderLayout.NORTH);

	      var textArea = new JTextArea("ʣ��Ԫ��:\n",TEXTAREA_ROWS, TEXTAREA_COLUMNS);

	      add(textArea, BorderLayout.WEST);
	      add(textArea2, BorderLayout.EAST);
	      		
	      Button1.addActionListener(event ->
	      {		          	  
	    	  Q = "delete from in_store_bill"
	    			  +getQ("in_store_bill_id", in_store_bill_id.getText().toString())
	    			  +getQ("storehouse_id", storehouse_id.getText().toString())
	    			  +getQ("supplier_id", supplier_id.getText().toString())+";";
	    	  System.out.println(Q);
	          Connection conn = GetConnection("joe", "20010403Me");
	    	  try {
				Delete(conn, Q);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	    	  
	      }
	    		  );
	      
	      Button2.addActionListener(event ->
	      {		     		 
	    	  first = true;     
	    	  textArea.setText("��ѯ���:\n"); 
	    	  textArea.append("in_store_bill_id	storehouse_id	supplier_id\n");
	          Q="select * from in_store_bill;";
	          Connection conn = GetConnection("joe", "20010403Me");
	 		  Query(conn, Q);
	          try {
	 			Scanner input = new Scanner(file);
	 			while (input.hasNextLine()) {
	 				textArea.append(input.nextLine()+"\n");	//����ѯ��������Ŀ���
	 			}
		        input.close();
	 		} catch (FileNotFoundException e) {
	 			// result.txt�ļ�Ҫ����
	 			e.printStackTrace();
	 		}  
	      }
	    		  );
	      pack();
  }
}
